#!/bin/sh

dicom_ids=()
for dirname in /input/*.zip; do
    id=${dirname#/input/}
    id=${id%/}
    id=${id%.*}
    if [ ! -e "/output/fmriprep/subj_done/sub-$id.html" ]; then
        #time unzip -o -d /tmp/tosort_$id $dirname >> /dev/null
        #cp -r $dirname /tmp/tosort_$id
        dicom_ids+=( "$id" )
    fi
done

parallel --jobs 30 --progress unzip -qq -o -d /output/tosort_{1} /input/{1}.zip ::: ${dicom_ids[@]}

find /output/tosort_* -name "DICOMDIR" -delete 
parallel --jobs 5 --timeout 300% --progress --joblog /output/sort.txt python3 /code/dicomsort/dicomsort.py -d -f /output/tosort_{1} /output/DICOM/{1}/%StudyDate/%SeriesNumber_%SeriesDescription/%InstanceNumber.dcm ::: ${dicom_ids[@]}
echo "Sorting - done"
#parallel --jobs 15 --timeout 300% --progress --joblog /output/series_uid.txt python3 /code/study_uid.py -s {1} ::: ${dicom_ids[@]} & wait $!
#echo "Series UIDs - done"
parallel --jobs 5 --timeout 300% --progress --joblog /output/convert.txt heudiconv -d /output/DICOM/{subject}/*/*/* -f /code/heuristic.py -s {1} -c dcm2niix -b --overwrite -o /output/BIDS --grouping all ::: ${dicom_ids[@]} 
echo "Convert to BIDS - done" 

#all_ids=()
#for dirname in /output/BIDS/sub-*; do
#    id=${dirname#/output/BIDS/sub-}
#    id=${id%/}
#    if [ ! -e "/output/fmriprep/subj_done/sub-$id.html" ]; then
#        # no output file corresponding to this ID found,
#        # add it to he list
#        all_ids+=( "$id" )
#    fi
#done

#fmriprep_pll() {
#  If [[ -d /output/BIDS/sub-“$1”/func ]]:
#    fmriprep /output/BIDS /output participant --fs-license-file /opt/freesurfer/license.txt --ignore fieldmaps --force-bbr -w /output --participant_label “$1”
#  else:
#    fmriprep /output/BIDS /output participant --anat-only --fs-license-file /opt/freesurfer/license.txt --ignore fieldmaps --force-bbr -w /output --participant_label “$1”
#}
#export -f fmriprep_pll

#printf 'Found ID: %s\n' "${all_ids[@]}"
#parallel --jobs 1  --timeout 150% --progress --joblog /output/preprocessing.txt fmriprep /output/BIDS /output participant --skip_bids_validation --fs-license-file /opt/freesurfer/license.txt --ignore fieldmaps --force-bbr -w /output --participant_label {1} ::: ${all_ids[@]} & wait $!
#echo "FMRIPreprecessing - done"

#parallel --jobs 5  --timeout 300% --progress --joblog /output/preprocessing.txt fmriprep_pll ::: ${all_ids[@]} & wait $!


#find /tmp -mindepth 1 -delete
#echo "Temp files cleared"

