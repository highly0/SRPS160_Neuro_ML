import pydicom
import glob
from tqdm import tqdm
import argparse
import os

parser = argparse.ArgumentParser()
parser.add_argument('-s', '--subject', help='Subject ID', required=True)
args = parser.parse_args()

subject = args.subject

alldcm = glob.glob(f'/tmp/DICOM/{subject}/*/*/*')
for jj in tqdm(range(0,len(alldcm))):
    ds = pydicom.dcmread(alldcm[jj])
    if jj is 0:
        studyUID = ds.StudyInstanceUID
    ds.StudyInstanceUID= studyUID
    ds.save_as(alldcm[jj])
